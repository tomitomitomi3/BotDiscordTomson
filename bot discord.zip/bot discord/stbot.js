const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, EmbedBuilder } = require('discord.js');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const { EventEmitter } = require('events');
const eventEmitter = new EventEmitter();
const { SlashCommandBuilder } = require('@discordjs/builders');
const fs = require('fs').promises;

const FILE_PATH = './nicknames.json';
const apiKey = 'fc5f364f-0a737374-e774cbdc-fa7fa17f';  // Tu API Key de FortniteAPI.io

const intervaltime = 6 * 60 * 60 * 1000;

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const TOKEN = 'MTI4OTY2MTA0MzI2OTcwMTcxMg.GF369V.A9UOQsPPu-m51_GIOg0iqMrfvyJ9pbjBwGVh2o';
const CHANNEL_ID = '1127622362901258292';
const CHANNEL_ID_2='1290864293469884529';

async function verifyFortniteUser(username) {
    const url = `https://fortniteapi.io/v1/lookup?username=${username}`;
    
    try {
        const response = await fetch(url, {
            headers: { 'Authorization': apiKey }
        });
        const data = await response.json();
        
        if (response.ok && data.account_id) {
            return true; // Cuenta válida
        } else {
            return false; // Cuenta no válida
        }
    } catch (error) {
        console.error('Error:', error);
        return false; // Error en la verificación
    }
}

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    const channel = await client.channels.fetch(CHANNEL_ID);
    if (channel) {
        const embed = new EmbedBuilder()
            .setColor('#8A2BE2')
            .setTitle('¡Bienvenido al sistema de nicknames!')
            .setDescription('Haz click en el botón de abajo para enviar tu nickname de Fortnite.\n Te enviaremos solicitud de amistad en Fortnite. **Acepta por favor TODAS.**');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('submit-nick')
                .setLabel('Enviar Nickname')
                .setStyle(ButtonStyle.Primary)
        );

        await channel.send({ embeds: [embed], components: [row] });
    } else {
        console.log('El canal no fue encontrado.');
    }
}, intervaltime);

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    const channel = await client.channels.fetch(CHANNEL_ID_2);
    if (channel) {
        const embed = new EmbedBuilder()
            .setColor('#8A2BE2')
            .setTitle('¡Bienvenido al sistema de nicknames!')
            .setDescription('Haz click en el botón de abajo para enviar tu nickname de Fortnite.\n Te enviaremos solicitud de amistad en Fortnite. **Acepta por favor TODAS.**');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('submit-nick')
                .setLabel('Enviar Nickname')
                .setStyle(ButtonStyle.Primary)
        );

        await channel.send({ embeds: [embed], components: [row] });
    } else {
        console.log('El canal no fue encontrado.');
    }
});

async function saveNicknames(nicknames) {
    await fs.writeFile(FILE_PATH, JSON.stringify(nicknames, null, 4));
}

async function loadNicknames() {
    try {
        const data = await fs.readFile(FILE_PATH, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.log("No se encontró el archivo, creando uno nuevo.");
        return {};
    }
}

client.on('interactionCreate', async interaction => {
    if (interaction.isButton() && interaction.customId === 'submit-nick') {
        const modal = new ModalBuilder()
            .setCustomId('nickname-modal')
            .setTitle('Enviar Nickname');

        const nicknameInput = new TextInputBuilder()
            .setCustomId('nicknameInput')
            .setLabel('Escribe tu Nickname')
            .setStyle(TextInputStyle.Short);

        const actionRow = new ActionRowBuilder().addComponents(nicknameInput);
        modal.addComponents(actionRow);

        await interaction.showModal(modal);
    }

    if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'nickname-modal') {
        const nickname = interaction.fields.getTextInputValue('nicknameInput');
        const userId = interaction.user.id;

        // Verificar si el nickname es válido en la API de Fortnite
        const isValid = await verifyFortniteUser(nickname);

        if (isValid) {
            // Cargar los nicknames guardados
            const nicknames = await loadNicknames();
            
            if (!nicknames[userId].includes(nickname)) {
                // Verificar si el usuario ya tiene un nickname, si es string convertirlo a array
                if (!Array.isArray(nicknames[userId])) {
                    nicknames[userId] = [nicknames[userId]].filter(Boolean);
                }
                // Añadir el nuevo nickname al array del usuario
                nicknames[userId].push(nickname);

                // Guardar los cambios en el archivo
                await saveNicknames(nicknames);

                // Responder al usuario
                const embed = new EmbedBuilder()
                    .setColor('#07a824')
                    .setTitle('¡Tu usuario se guardo correctamente!')
                    .setDescription(`${interaction.user} Tu usuario: **${nickname}**. Recuerda agregar tus otras cuentas tambien y aceptar las solicitudes de amistad.`);

                await interaction.reply({ embeds: [embed] });

                // Borrar el mensaje después de 10 segundos
                setTimeout(async () => {
                    await interaction.deleteReply();
                }, 10000);
            } else {
                // Si el nickname ya está en la lista
                const embed = new EmbedBuilder()
                    .setColor('#d1530a')
                    .setTitle('Tu usuario ya esta ingresado.')
                    .setDescription(`${interaction.user} Tu usuario: **${nickname}** ya esta ingresado.`);

                await interaction.reply({ embeds: [embed] });

                // Borrar el mensaje después de 10 segundos
                setTimeout(async () => {
                    await interaction.deleteReply();
                }, 10000);
            }   
        } else {
            // Responder al usuario que el nickname es inválido
            const embed = new EmbedBuilder()
                .setColor('#a80707')
                .setTitle('Tu usuario **no es valido**')
                .setDescription(`${interaction.user} Tu usuario: **${nickname}** es erroneo. Prueba de nuevo.`);

            await interaction.reply({ embeds: [embed] });
    //        await interaction.reply(`El nickname ${nickname} no es válido. Por favor, verifica tu nombre de usuario en Fortnite.`);

            // Borrar el mensaje después de 10 segundos
            setTimeout(async () => {
                await interaction.deleteReply();
            }, 10000);
        }
    }

    if (interaction.isCommand() && interaction.commandName === 'usuarioview') {
        const userId = interaction.user.id;
        eventEmitter.emit('viewName', userId);
        await interaction.reply({ content: 'Buscando tu nickname...', ephemeral: false });
    }
});

client.login(TOKEN);
