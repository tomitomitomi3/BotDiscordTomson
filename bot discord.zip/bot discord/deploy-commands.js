const { REST, Routes, SlashCommandBuilder } = require('discord.js');
const { clientId, guildId, token } = require('./config.json');  // Asegúrate de tener estos valores en config.json

const commands = [
    {
        name: 'friend_acceptall',
        description: 'Acepta todas las solicitudes de amistad en Wafer',
        options: [
            {
                name: 'bulk',
                type: 5,  // Booleano
                description: 'Acepta todas en modo bulk',
                required: true,
            }
        ]
    },
    // Agregar el nuevo comando /usuario
    new SlashCommandBuilder()
        .setName('usuario')
        .setDescription('Administra tu nickname')
        .addStringOption(option =>
            option.setName('subcomando')
                .setDescription('view para ver tu nickname registrado')
                .setRequired(false)
        ).toJSON(),  // Convertir el comando a JSON
];
const rest = new REST({ version: '10' }).setToken(token);

(async () => {
    try {
        console.log('Iniciando el registro de comandos.');

        await rest.put(
            Routes.applicationGuildCommands(clientId, guildId),
            { body: commands },
        );

        console.log('Comandos registrados con éxito.');
    } catch (error) {
        console.error(error);
    }
})();
