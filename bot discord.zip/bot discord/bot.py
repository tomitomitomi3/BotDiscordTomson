from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import json
import time

# Configura el controlador de Selenium sin headless (con interfaz gráfica)
options = Options()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-gpu")
options.add_argument("--remote-debugging-port=9222")

driver = webdriver.Chrome(options=options)

# Abre Discord e inicia sesión
driver.get("https://discord.com/login")
time.sleep(5)

# Inicia sesión
email_input = driver.find_element(By.NAME, "email")
password_input = driver.find_element(By.NAME, "password")

email_input.send_keys("ftjnewvision@gmail.com")  # Ingresar tu correo
password_input.send_keys("passfortomi1")  # Ingresar tu contraseña
password_input.submit()
time.sleep(10)

# Navega al servidor y canal donde quieres enviar el mensaje
driver.get("https://discord.com/channels/1126637195168579675/1289669273119232135")
time.sleep(5)

# Leer el archivo JSON que contiene los nicknames
with open('nicknames.json', 'r', encoding='utf-8') as file:
    nicknames = json.load(file)
def type_slowly(element, text, delay=0.1):
    """Simula la escritura lenta enviando un carácter a la vez."""
    for char in text:
        element.send_keys(char)
        time.sleep(delay)
# Ciclo para esperar comandos
while True:
    user_input = input("Escribe 'enviar' para procesar los nicknames o 'salir' para terminar: ").lower()

    if user_input == "enviar":
        # Iterar sobre cada usuario y su array de nicknames
        for user_id, nickname_list in nicknames.items():
            if isinstance(nickname_list, list):
                for nickname in nickname_list:
                    # Encuentra el campo de entrada de mensaje
                    message_input = driver.find_element(By.CSS_SELECTOR, "div[role='textbox']")

                    # Envía el comando con el nickname
                    command = f"/friend add player:{nickname}"
                    message_input.send_keys(command)
                    message_input.send_keys("\t") 
                    command = f" bulk:true"
                    message_input.send_keys(command)
                    time.sleep(5)  # Espera un poco entre mensajes
                    message_input.send_keys("\n") 
                    message_input.send_keys("\n") 
             #       message_input.send_keys("\n")  # Presiona Enter para enviar
            else:
                print(f"Error: {nickname_list} no es una lista de nicknames.")
    elif user_input == "salir":
        print("Cerrando el navegador y terminando el script.")
        break
    else:
        print("Comando no reconocido. Escribe 'enviar' o 'salir'.")

# No cerrar el navegador hasta que se escriba "salir"
driver.quit()
